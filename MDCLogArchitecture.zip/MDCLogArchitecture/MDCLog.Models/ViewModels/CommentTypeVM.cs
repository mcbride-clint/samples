﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MDCLogArchitecture.Models.ViewModels
{
   public class CommentTypeVM
    {
        public string CommentTypeCode { get; set; }
        public string TypeDesc { get; set; }
    }
}
