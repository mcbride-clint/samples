﻿using System;

namespace MDCLogArchitecture.Models.Filters
{
    public class PriorityCodesFilter
    {
        
        public int? Priority { get; set; }
        public string Descr { get; set; }
        

    }
   
}
