﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MDCLogArchitecture.Models.DomainModels
{
    class StatusCode
    {
        public string Status { get; set; }
        public string Descr { get; set; }
    }
}
