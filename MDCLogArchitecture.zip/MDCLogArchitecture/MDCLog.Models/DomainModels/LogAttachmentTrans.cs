﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MDCLogArchitecture.Models.DomainModels
{
    public class LogAttachmentTrans
    {
        public int LogAttachSeqNum { get; set; }
        public int LogNumber { get; set; }
    }
}
