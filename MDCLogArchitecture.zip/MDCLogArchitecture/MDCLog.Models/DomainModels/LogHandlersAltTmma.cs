﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MDCLogArchitecture.Models.DomainModels
{
    class LogHandlersAltTmma
    {
        public int UserSeqNum { get; set; }
        public string AltTmma { get; set; }
    }
}
