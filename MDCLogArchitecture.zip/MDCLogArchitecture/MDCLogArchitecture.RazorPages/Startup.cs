using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using MDCLogArchitecture.DataAccess.Repositories;
using MDCLogArchitecture.Domain.Interfaces.Repositories;
using MDCLogArchitecture.Domain.Services;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace MDCLogArchitecture.RazorPages
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //string connString = @"Server=DESKTOP-UV36790\SQLDRA;Database=MDC;Trusted_Connection = True;";
            //string connString = @"Server=DESKTOP-KH6A94U;Database=MDC;Trusted_Connection = True;";
            string connString = @"Server=DESKTOP-KH6A94U;Database=MDC;Trusted_Connection = True;";
            services.AddScoped<IDbConnection, SqlConnection>(c => {
                return new SqlConnection(connString);
            });

            services.AddScoped<ILogCommentsRepository, LogCommentsRepository>();
            services.AddScoped<ICommentTypesRepository,CommentsTypeRepository>();
           
            services.AddScoped<IPriorityRepository, PriorityRepository>();
            services.AddScoped<MDCLogService>();
            services.AddScoped<CommentTypeService>();
            services.AddScoped<PriorityCodeService>();
            
            services.AddRazorPages();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
            });
        }
    }
}
